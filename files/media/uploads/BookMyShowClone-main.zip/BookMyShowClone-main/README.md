# BookMyShowClone
Front end project - BookMyShowClone. Using only HTML and CSS. It is a stati webpage to understand the positioning of the webpage.
